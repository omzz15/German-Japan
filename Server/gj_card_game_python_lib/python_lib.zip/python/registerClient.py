import json
import boto3
from types import SimpleNamespace
from client import Client
import constants


def object_to_dict(object):
    dict = vars(object)
    for k,v in dict.items():
        if type(v).__name__ not in ['list', 'dict', 'str', 'int', 'float']:
                dict[k] = object_to_dict(v)
        if type(v) is list:
            dict[k] = list_object_to_dict(v)
    return dict

def lambda_function_impl(event, context):
    cid = None
    if 'clientId' not in event or event['clientId'] == 0:
        obj = constants.s3_res.Object(constants.bucket, constants.id_file)
        obj_body = obj.get()['Body']
        idObj = json.loads(obj_body.read(), object_hook=lambda d: SimpleNamespace(**d))
        cid = idObj.next_client_id
        idObj.next_client_id += 1
        idDict = object_to_dict(idObj)
        obj.put(Body=json.dumps(idDict))
    else:
        cid = event['clientId']
    eBody = event['body']
    c = Client.from_json(eBody)
    c.id = cid
    client_file = f'{cid}.json'
    obj = constants.s3_res.Object(constants.bucket, constants.client_folder + client_file)
    obj.put(Body=json.dumps(object_to_dict(c)))
    return {
        'statusCode': 200,
        'body': json.dumps(object_to_dict(c))
    }
